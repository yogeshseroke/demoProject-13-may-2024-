package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.User;
import com.example.demo.requestDto.UserRequestDto;
import com.example.demo.responseDto.UserResponseDto;
import com.example.demo.service.UserService;

@RestController
@RequestMapping("/userController")
public class UserController {

	@Autowired
	private UserService userService;
	
	@PostMapping("/saveUser")
	public User saveUser(@RequestBody UserRequestDto user) {
		return userService.saveUser(user);
	}
	
	@GetMapping("/getUsers")
	public List<UserResponseDto> getUsers(){
		return userService.getUsers();
	}
	
	@PostMapping("/reportOfUsers")
	List<UserResponseDto> reportOfUsers(@RequestBody UserRequestDto user){
		return userService.reportOfUsers(user);
	}
}


