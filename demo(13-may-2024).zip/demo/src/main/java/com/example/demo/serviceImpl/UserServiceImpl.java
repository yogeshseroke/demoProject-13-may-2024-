package com.example.demo.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.requestDto.UserRequestDto;
import com.example.demo.responseDto.UserResponseDto;
import com.example.demo.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public User saveUser(UserRequestDto user) {
		
		User map = modelMapper.map(user, User.class);
		User save = userRepository.save(map);
		return save;
	}

	@Override
	public List<UserResponseDto> getUsers() {
		List<User> all = userRepository.findAll();
		if(all.isEmpty()) {
			return null;
		}else {
			List<UserResponseDto> dtos = new ArrayList();
			for (User user : all) {
				UserResponseDto map = modelMapper.map(user, UserResponseDto.class);
				dtos.add(map);
			}
			return dtos;
		}

	}

	@Override
	public List<UserResponseDto> reportOfUsers(UserRequestDto user) {
		try {
			
			List<UserResponseDto> dtos = new ArrayList<>();

			//filter based on userName
			if (user.getAmount() == 0 && user.getBankName().equals("") && !user.getUName().equals("")) {
				List<User> byUserName = userRepository.findByUserName(user.getUName());

				if (byUserName.isEmpty()) {
					return null;
				} else {

					for (User user1 : byUserName) {
						UserResponseDto map = modelMapper.map(user1, UserResponseDto.class);
						dtos.add(map);
					}
					return dtos;
				}
			}

			//filter based on Amount
			if (user.getAmount() != 0 && user.getBankName().equals("") && user.getUName().equals("")) {
				List<User> byUserName = userRepository.findByAmount(user.getAmount());

				if (byUserName.isEmpty()) {
					return null;
				} else {

					for (User user1 : byUserName) {
						UserResponseDto map = modelMapper.map(user1, UserResponseDto.class);
						dtos.add(map);
					}
					return dtos;
				}
			}
			
			//filter based on BankName
			if (user.getAmount() == 0 && !user.getBankName().equals("") && user.getUName().equals("")) {
				List<User> byUserName = userRepository.findByBankName(user.getBankName());

				if (byUserName.isEmpty()) {
					return null;
				} else {

					for (User user1 : byUserName) {
						UserResponseDto map = modelMapper.map(user1, UserResponseDto.class);
						dtos.add(map);
					}
					return dtos;
				}
			}
			
			//filter based on BankName And Amount
			if (user.getAmount() != 0 && !user.getBankName().equals("") && user.getUName().equals("")) {
				List<User> byUserName = userRepository.findByBankNameAndAmount(user.getBankName(), user.getAmount());

				if (byUserName.isEmpty()) {
					return null;
				} else {

					for (User user1 : byUserName) {
						UserResponseDto map = modelMapper.map(user1, UserResponseDto.class);
						dtos.add(map);
					}
					return dtos;
				}
			}

			return null;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}

	}

}
